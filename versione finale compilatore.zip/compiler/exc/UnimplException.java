package compiler.exc;

public class UnimplException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
