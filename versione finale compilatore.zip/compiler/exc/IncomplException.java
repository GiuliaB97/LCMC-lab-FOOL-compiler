package compiler.exc;

public class IncomplException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
